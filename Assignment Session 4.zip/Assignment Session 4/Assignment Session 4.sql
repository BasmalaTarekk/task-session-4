--Assignment Session 4

--1 
USE StoreDB
SELECT COUNT(*) AS Total_Products
FROM production.products;

------------------------------------
--2
SELECT 
 AVG(list_price) AS Average_Price,
 MIN(list_price) AS Min_Price,
 MAX(list_price) AS Max_Price
FROM production.products;

------------------------------------
--3 
SELECT 
  category_id, 
  COUNT(*) AS Product_Count
FROM production.products
GROUP BY category_id;

------------------------------------
--4 
SELECT 
   store_id,
   COUNT(*) AS Total_Orders
FROM sales.orders
GROUP BY store_id;

------------------------------------
--5
SELECT TOP 10
  UPPER(first_name) AS First_Name,
  UPPER(last_name) AS Last_Name
FROM sales.customers
ORDER BY customer_id;

------------------------------------
--6
SELECT TOP 10
    product_name,
    LEN(product_name) AS Name_length
FROM production.products
ORDER BY product_id;

-----------------------------------
--7
SELECT TOP 15
    customer_id,
    LEFT(phone, 3) AS area_code
FROM sales.customers
ORDER BY customer_id;

----------------------------------
--8 
SELECT TOP 10
    order_id,
    GETDATE() AS order_date,
    YEAR(order_date) AS Order_year,
    MONTH(order_date) AS Order_month
FROM sales.orders
ORDER BY order_id;

-----------------------------------
--9
SELECT TOP 10
    p.product_name,  c.category_name
FROM production.products p
JOIN production.categories c ON p.category_id = c.category_id
ORDER BY p.product_id;

------------------------------------
--10
SELECT TOP 10
    CONCAT(c.first_name, ' ', c.last_name) AS Customer_Name,
    o.order_date
FROM sales.orders o
JOIN sales.customers c ON o.customer_id = c.customer_id
ORDER BY o.order_id;

-------------------------------------
--11
SELECT
    p.product_name,
    ISNULL(b.brand_name, 'No Brand') AS Brand_Name
FROM production.products p
LEFT JOIN production.brands b ON p.brand_id = b.brand_id
ORDER BY p.product_id;

---------------------------------------
--12
SELECT
    product_name, list_price
FROM production.products
WHERE list_price > (SELECT AVG(list_price) FROM production.products)
ORDER BY list_price DESC;

----------------------------------------
--13
SELECT
    customer_id,
    CONCAT(first_name, ' ', last_name) AS Customer_Name
FROM sales.customers
WHERE customer_id IN (SELECT DISTINCT customer_id FROM sales.orders);

----------------------------------------
--14
SELECT
    c.customer_id,
    CONCAT(c.first_name, ' ', c.last_name) AS Customer_Name,
    (SELECT COUNT(*) FROM sales.orders o WHERE o.customer_id = c.customer_id) AS Total_Orders
FROM sales.customers c
ORDER BY c.customer_id;

----------------------------------------
--15
CREATE VIEW easy_product_list AS
SELECT
    p.product_name,
    c.category_name,
    p.list_price
FROM production.products p
JOIN production.categories c ON p.category_id = c.category_id;

SELECT *
FROM easy_product_list
WHERE list_price > 100;
-----------------------------------------
--16
CREATE VIEW customer_info AS
SELECT
    customer_id,
    CONCAT(first_name, ' ', last_name) AS Customer_Name,
    email,
    CONCAT(city, ', ', state) AS City_State
FROM sales.customers;

SELECT *
FROM customer_info
WHERE city_state LIKE '%, CA';

------------------------------------------
--17
SELECT
    product_name, list_price
FROM production.products
WHERE list_price BETWEEN 50 AND 200
ORDER BY list_price ASC;

-------------------------------------------
--18
SELECT
    state,
    COUNT(*) AS Customer_Count
FROM sales.customers
GROUP BY state
ORDER BY customer_count DESC;

-------------------------------------------
--19
SELECT
    c.category_name,
    p.product_name,
    p.list_price
FROM production.products p
JOIN production.categories c ON p.category_id = c.category_id
WHERE p.list_price = (
    SELECT MAX(list_price) FROM production.products WHERE category_id = p.category_id
)
ORDER BY c.category_name;

--------------------------------------------
--20
SELECT
    s.store_name, s.city,
    COUNT(o.order_id) AS order_count
FROM sales.stores s
LEFT JOIN sales.orders o ON s.store_id = o.store_id
GROUP BY s.store_name, s.city
ORDER BY s.store_name;

---------------------------------------------







